from django.apps import AppConfig


class ProFileConfig(AppConfig):
    name = 'pro_file'
