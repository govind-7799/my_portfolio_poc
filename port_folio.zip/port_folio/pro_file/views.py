from django.shortcuts import render


def display(request):
    return render(request, 'demo.html')


def home(request):
    return render(request,'home.html')


def about(request):
    return render(request,'about.html')


def contact(request):
    return render(request, 'contact.html')


def project(request):
    return render(request, 'project.html',)
